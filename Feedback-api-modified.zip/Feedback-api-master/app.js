
const express = require('express');
const bodyParser = require('body-parser');
const feedbackRoutes = require('./routes/feedbackRoutes');
const app = express();

app.use(bodyParser.urlencoded({ extended: false }));

// Serve static files with caching
app.use('/public', express.static('public', {
    maxAge: '1d', // Cache static files for one day
}));

app.set('view engine', 'ejs');

app.use('/feedback', feedbackRoutes);

module.exports = app;
